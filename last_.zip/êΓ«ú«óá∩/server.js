const express = require('express');
const axios = require('axios');
const cors = require('cors');
const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.json());

// База данных ключевых слов и URL (в реальном приложении используйте БД)
const keywordDatabase = {
    'javascript': [
        { url: 'https://developer.mozilla.org/en-US/docs/Web/JavaScript', title: 'MDN JavaScript Docs' },
        { url: 'https://javascript.info/', title: 'Modern JavaScript Tutorial' },
        { url: 'https://eloquentjavascript.net/', title: 'Eloquent JavaScript' }
    ],
    'nodejs': [
        { url: 'https://nodejs.org/en/docs/', title: 'Node.js Official Docs' },
        { url: 'https://www.tutorialspoint.com/nodejs/', title: 'Node.js Tutorial' }
    ],
    'react': [
        { url: 'https://reactjs.org/docs/getting-started.html', title: 'React Official Docs' },
        { url: 'https://react-tutorial.app/', title: 'React Tutorial' }
    ]
};

// Получение URL по ключевому слову
app.get('/api/search/:keyword', (req, res) => {
    const keyword = req.params.keyword.toLowerCase();
    
    if (keywordDatabase[keyword]) {
        res.json({
            success: true,
            results: keywordDatabase[keyword]
        });
    } else {
        res.status(404).json({
            success: false,
            message: 'No URLs found for this keyword'
        });
    }
});

// Загрузка контента с прогрессом
app.get('/api/download', async (req, res) => {
    const url = req.query.url;
    
    if (!url) {
        return res.status(400).json({ error: 'URL parameter is required' });
    }

    try {
        const response = await axios({
            method: 'get',
            url: url,
            responseType: 'stream'
        });

        // Получаем размер контента
        const contentLength = response.headers['content-length'];
        let downloadedBytes = 0;

        res.setHeader('Content-Type', response.headers['content-type']);
        res.setHeader('Content-Length', contentLength);

        // Отправляем прогресс загрузки
        response.data.on('data', (chunk) => {
            downloadedBytes += chunk.length;
            const progress = (downloadedBytes / contentLength) * 100;
            
            // В реальном приложении здесь можно отправлять прогресс через WebSocket
            console.log(`Download progress: ${progress.toFixed(2)}%`);
        });

        response.data.pipe(res);
    } catch (error) {
        console.error('Download error:', error);
        res.status(500).json({ error: 'Failed to download content' });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});